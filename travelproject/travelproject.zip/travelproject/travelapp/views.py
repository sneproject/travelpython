from django.http import HttpResponse
from django.shortcuts import render


# Create your views here.


def about(request):

    return render(request, "about.html")


def addition(request):
    x = int(request.GET.get['num1'])
    y = int(request.GET.get['num2'])
    res = x + y
    return render(request, "result.html", {'result': res})
